#include<iostream>
using namespace std;
int main()
{
    int a[]={1,2,2,3,4,5,5,2,2},size;
    size=sizeof(a)/sizeof(int);
    cout<<"size of array is :"<<size;
    return 0;
}
